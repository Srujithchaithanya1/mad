package com.example.horizontalform

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var inp=findViewById<EditText>(R.id.input)
        var opt=findViewById<TextView>(R.id.output)
        var btn=findViewById<Button>(R.id.Submit)
        btn.setOnClickListener(){
            opt.text=inp.text.toString()
            Toast.makeText(this,"Button Clicked",Toast.LENGTH_SHORT).show()
            }
    }
}